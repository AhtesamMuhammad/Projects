This is my first project in JavaScript. I wanted to make a calculator because I think it's an easy way to practice.
Maybe I have some mistakes that I could not see. Nothing more to say.

Ahtesam Muhammad
ahtesam.work@gmail.com