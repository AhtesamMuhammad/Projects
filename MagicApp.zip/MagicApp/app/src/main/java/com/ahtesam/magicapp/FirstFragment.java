package com.ahtesam.magicapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ahtesam.magicapp.databinding.FragmentFirstBinding;
import com.google.android.material.snackbar.Snackbar;

public class FirstFragment extends Fragment {

    private int life1 = 20;
    private int life2 = 20;
    private int poison1 = 0;
    private int poison2 = 0;

    public void incLife1() {
        life1++;
    }

    public void incLife2() {
        life2++;
    }

    public void decLife1() {
        life1--;
    }

    public void decLife2() {
        life2--;
    }

    public void incPoison1() {
        poison1++;
    }

    public void incPoison2() {
        poison2++;
    }

    public void decPoison1() {
        poison1--;
    }

    public void decPoison2() {
        poison2--;
    }

    private FragmentFirstBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        updateViews();
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (savedInstanceState != null) {
            life1 = savedInstanceState.getInt("life1");
            life2 = savedInstanceState.getInt("life2");
            poison1 = savedInstanceState.getInt("poison1");
            poison2 = savedInstanceState.getInt("poison2");

            updateViews();
        }

        binding.lifeOneToTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decLife1();
                incLife2();
                updateViews();
            }
        });

        binding.lifeTwoToOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decLife2();
                incLife1();
                updateViews();
            }
        });

        binding.p1PoisonMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incPoison1();
                updateViews();
            }
        });

        binding.p1PoisonLess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decPoison1();
                updateViews();
            }
        });

        binding.p2PoisonMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incPoison2();
                updateViews();
            }
        });

        binding.p2PoisonLess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decPoison2();
                updateViews();
            }
        });

        binding.p1LifeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incLife1();
                updateViews();
            }
        });

        binding.p1LifeLess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decLife1();
                updateViews();
            }
        });

        binding.p2LifeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incLife2();
                updateViews();
            }
        });

    }

    //Show the update every time is clicked on
    private void updateViews() {
        binding.counterP1.setText(String.format("%d/%d", life1, poison1));
        binding.counterP2.setText(String.format("%d/%d", life2, poison2));
    }

    //This method helps not to delete data when rotation the screen horizontally
    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("life1", life1);
        outState.putInt("life2", life2);
        outState.putInt("poison1", poison1);
        outState.putInt("poison2", poison2);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    //This method create another button of reset that is not correct
//    @Override
//    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
//        super.onCreateOptionsMenu(menu, inflater);
//        inflater.inflate(R.menu.menu_main, menu);
//    }

    public void reset() {
        life1 = 20;
        life2 = 20;
        poison1 = 0;
        poison2 = 0;
        updateViews();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.reset) {
            reset();
            //Its not defined view in this context,
            //So if we want to show in the actual fragment, we have to use requireView
            Snackbar.make(requireView(), "New Game!", Snackbar.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}